# Bitstream Bounce — Step 2 audition pack (Bratz revision)

## Playback notes

- The original files are copied unchanged under `primary/raw` and `alternates/raw`.
- WAV previews are non-normalized and preserve the archive amplitudes. Raw samples are interpreted as signed 8-bit mono at 8287 Hz, then resampled to 44100 Hz for ordinary audio players.
- `primary_montage_raw_levels.wav` preserves archive amplitudes.
- `primary_montage_recommended_volumes.wav` applies the recommended ProTracker default sample volumes.
- `bratz_register_audition.wav` plays Bratz at tracker notes C-3, F-3, A-3, and C-4, in that order, at volume `24`.
- All finetunes remain `00`.

## Primary eight-slot set

| Slot | Sample | Role | Default volume | Loop | Tracker range |
|---|---|---|---:|---|---|
| 01 | ST-01/Strings7 | opening drone/pad | `20` | yes | `C-4..B-5` |
| 02 | ST-02/Bratz | provisional brass lead; phrase like sax | `24` | no | `C-3..B-4` |
| 03 | ST-01/SlapBass | bass | `1c` | no | `C-4..B-5`; keep normal lines mostly in octave 4 |
| 04 | ST-02/BassDrum5 | kick | `20` | no | `C-4` only |
| 05 | ST-01/Snare4 | snare | `20` | no | `C-4` only |
| 06 | ST-01/HiHat2 | closed hi-hat | `18` | no | `C-4` only |
| 07 | ST-01/MuteClav | syncopated comping | `1c` | no | `C-4..B-5` |
| 08 | ST-01/CowBell | party accent/fills | `14` | no | `C-4` only |

Volumes are hexadecimal; `40` is maximum.

## Bratz analysis

- Length: 6500 bytes, 0.784 seconds at 8287 Hz.
- Peak: 0.00 dBFS; RMS: -11.38 dBFS.
- The smoothed envelope reaches its main peak at about 64 ms, falls below 20% of that peak at about 522 ms, and is near silence by the end.
- The sample is strongly tonal, with an estimated fundamental near 259.0 Hz at native playback.
- Do not loop it. The attack and natural decay are part of the brass articulation.
- Default volume `24` leaves space for accent notes to rise to roughly `28`-`2c` with per-row volume changes.

## Sax-like writing constraints for the provisional brass lead

1. Write monophonically.
2. Use short, breath-shaped phrases and deliberate gaps; the sample is under 0.8 seconds long.
3. Retrigger sustained notes rather than pretending the sample has an endless air column.
4. Prefer bends into target notes, brief portamento, restrained vibrato, and occasional grace-note pickups.
5. Keep the core register in octave 3 and lower octave 4. Use the upper end sparingly so a later sax replacement remains practical.
6. Avoid chords, long organ-like holds, and rapid repeated notes that expose the trumpet-like attack too aggressively.

## Loop recommendation

Loop only `Strings7`. Search for a forward-loop pair in the stable middle/late body, roughly between source offsets `1000` and `1c00`; avoid the final falling section. Exact loop points must be chosen by ear in MilkyTracker. None of the other primary samples should be looped because their attacks and natural decays are part of their identity.

## Audition checklist

1. At provisional speed `06`, tempo `8a`, play `Strings7` at `C-4` under `Bratz` at `C-3`, `F-3`, and `A-3`.
2. Confirm that default volume `24` leads the drone without becoming abrasive. Test `22` and `26` as nearby alternatives.
3. Test bends, one- or two-row grace notes, and short vibrato on held notes. The line should suggest sax phrasing even though the source is brass.
4. Test the Strings7 forward loop for clicks, obvious periodic beating, and a volume step across the loop boundary.
5. Enter all percussion at `C-4`. Verify that kick and snare remain distinct when the hi-hat plays eighths or sixteenths.
6. Run SlapBass from `C-4` through `B-4`, then test octave-5 fills. Reject notes that become thin, buzzy, or pitch-ambiguous.
7. Try short offbeat MuteClav chords and sparse CowBell syncopations. They should add motion without masking the lead.
8. Audition with interpolation and external effects disabled first. Add tracker effects only after the raw sample balance is accepted.

## Alternates

- `Licks` and `Licks2`: retained as lead comparisons, but not selected.
- `Stabs`: broader accent voice in place of MuteClav.
- `HighVibes`: pitched jazz color in place of CowBell.
- `Snare9`: longer and brighter alternative to Snare4.
- `BassDrum1`: very compact but heavily clipped kick alternative.
- `CloseHiHat`: quieter, shorter closed-hat alternative.

The untrimmed primary sample payload is `89e4` bytes (35300 decimal), before the MOD header and pattern data. This saves 2600 bytes compared with the Blower set, though a final module below 40 KiB will still require sample shortening and very few stored patterns.
