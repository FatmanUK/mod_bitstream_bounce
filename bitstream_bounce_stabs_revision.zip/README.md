# Stabs replacement audition

## Files

- `stabs_placement_audition_A_G_D_C.wav`: `ST-01/Stabs` at A, G, D, then native C reference, each at `C24` relative level.
- `accent_candidate_comparison.wav`: Stabs, Great, Cinema, HighVibes, WarmBells, in that order, each at `C24` relative level and native pitch.
- `pattern03_stabs.md`: revised Pattern 03.
- `pattern04_current.md`: the user's supplied Pattern 04, copied unchanged.
- `pattern05_stabs.md`: revised Pattern 05.
- `instrument08_stabs_notes.md`: slot manifest, measurements, placements, and size impact.
- `ST-01_Stabs.raw`: unchanged source sample extracted from the supplied ST-01 archive.

WAV previews interpret raw samples as signed 8-bit mono at 8,287 Hz and resample to 44.1 kHz for ordinary playback. They are not normalized.
