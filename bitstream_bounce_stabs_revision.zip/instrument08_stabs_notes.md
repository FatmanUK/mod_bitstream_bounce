# Instrument 08 replacement: CowBell -> Stabs

## Decision

Replace slot `08` with `ST-01/Stabs`.

```yaml
"08":
  source: "ST-01/Stabs"
  role: "rare pitched brass/orchestral transition stab"
  volume_hex: "1c"
  finetune_hex: "00"
  loop: "none"
  working_range: "C-4..B-4"
```

## Measured character

- Raw length: 7,400 bytes
- Duration at 8,287 Hz: approximately 0.893 seconds
- Peak: 0.00 dBFS
- RMS: approximately -10.89 dBFS
- Main envelope peak: approximately 74 ms
- Falls below 20% of peak around 366 ms, followed by a quiet tail
- Spectral centroid: approximately 211 Hz; about 89% of measured energy lies below 500 Hz

The sample has considerably more low-mid body and decay than CowBell. It should therefore be treated as pitched harmonic punctuation, not unpitched percussion.

## Current placements

```text
Pattern 03, row 61: A-4 08 C24  # A-dominant turnaround
Pattern 05, row 31: G-4 08 C24  # closes the G-coloured phrase
Pattern 05, row 47: D-4 08 C24  # closes the D-coloured phrase
```

Start at `C24`. Test `C20`, `C24`, and `C28` in the compiled mix. The longer tail may make `C24` feel larger than CowBell at `C28`, particularly because all three placements avoid Snare4.

## Size impact

CowBell is 1,400 bytes; Stabs is 7,400 bytes. The replacement adds 6,000 bytes (`1770` hex) before any tail trimming. The sub-40-KiB target becomes substantially less realistic, but that target is secondary to the accepted sound.
