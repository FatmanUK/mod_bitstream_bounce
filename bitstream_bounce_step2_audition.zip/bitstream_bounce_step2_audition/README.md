# Bitstream Bounce — Step 2 audition pack

## Playback notes

- The original files are copied unchanged under `primary/raw` and `alternates/raw`.
- WAV previews are non-normalized and preserve the original relative amplitudes. They were interpreted as signed 8-bit mono at 8287 Hz, then resampled to 44100 Hz for ordinary audio players.
- `primary_montage_raw_levels.wav` preserves archive amplitudes.
- `primary_montage_recommended_volumes.wav` applies the recommended ProTracker default sample volumes.
- `sax_candidate_comparison_peak_matched.wav` is level-matched for timbre comparison only; order: Blower, Licks, Licks2.
- All finetunes remain `00`.

## Primary eight-slot set

| Slot | Sample | Role | Default volume | Loop | Tracker range |
|---|---|---|---:|---|---|
| 01 | ST-01/Strings7 | opening drone/pad | `20` | yes | `C-4..B-5` |
| 02 | ST-02/Blower | primary sax candidate | `28` | no | `C-3..B-4` |
| 03 | ST-01/SlapBass | bass | `1c` | no | `C-4..B-5`; keep normal lines mostly in octave 4 |
| 04 | ST-02/BassDrum5 | kick | `20` | no | `C-4` only |
| 05 | ST-01/Snare4 | snare | `20` | no | `C-4` only |
| 06 | ST-01/HiHat2 | closed hi-hat | `18` | no | `C-4` only |
| 07 | ST-01/MuteClav | syncopated comping | `1c` | no | `C-4..B-5` |
| 08 | ST-01/CowBell | party accent/fills | `14` | no | `C-4` only |

Volumes are hexadecimal; `40` is maximum.

## Loop recommendation

Loop only `Strings7`. Search for a forward-loop pair in the stable middle/late body, roughly between source offsets `1000` and `1c00`; avoid the final falling section. Exact loop points must be chosen by ear in MilkyTracker. None of the other primary samples should be looped because their attacks and natural decays are part of their identity.

## Audition checklist

1. At provisional speed `06`, tempo `8a`, play `Strings7` at `C-4` under `Blower` at `C-3`, `F-3`, and `A-3`. The lead should read as sax/reed, not generic brass, and its secondary swell should not sound like an accidental retrigger.
2. Compare Blower, Licks, and Licks2 in the peak-matched sax montage. Prefer the sample with the clearest reed identity, least objectionable note-start noise, and most useful sustain.
3. Test the Strings7 forward loop for clicks, obvious periodic beating, and a volume step across the loop boundary.
4. Enter all percussion at `C-4`. Verify that kick and snare remain distinct when the hi-hat plays eighths or sixteenths.
5. Run SlapBass from `C-4` through `B-4`, then test octave-5 fills. Reject notes that become thin, buzzy, or pitch-ambiguous.
6. Try short offbeat MuteClav chords and sparse CowBell syncopations. They should add motion without masking the sax.
7. Audition with interpolation and external effects disabled first. Add tracker effects only after the raw sample balance is accepted.

## Alternates

- `Licks` and `Licks2`: sax/lead comparisons.
- `Stabs`: broader accent voice in place of MuteClav.
- `HighVibes`: pitched jazz color in place of CowBell.
- `Snare9`: longer and brighter alternative to Snare4.
- `BassDrum1`: very compact but heavily clipped kick alternative.
- `CloseHiHat`: quieter, shorter closed-hat alternative.

The untrimmed primary sample payload is `940c` bytes (37900 decimal), before the MOD header and pattern data. A final module below 40 KiB will therefore require sample shortening and a very small number of stored patterns.
